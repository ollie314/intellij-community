/*
 * Copyright 2012 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.gradle.cli

import spock.lang.Specification

class ParsedCommandLineOptionSpec extends Specification {

    final option = new ParsedCommandLineOption();

    def "reports no value"() {
        when:
        option.getValue()

        then:
        thrown(IllegalStateException)
        !option.hasValue()
    }

    def "reports single value"() {
        when:
        option.addArgument("foo")

        then:
        option.hasValue()
        "foo" == option.value
        ["foo"] == option.values
    }

    def "reports multiple values"() {
        when:
        option.addArgument("foo")
        option.addArgument("bar")

        then:
        option.hasValue()
        ["foo", "bar"] == option.values

        when:
        option.getValue()

        then:
        thrown(IllegalStateException)
    }
}
