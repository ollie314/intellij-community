package org.gradle;

import org.junit.runner.RunWith;

@RunWith(CustomRunner.class)
public abstract class AbstractHasRunWith {
}