package org.gradle;

public class EmptyRunWithSubclass extends AbstractHasRunWith {

}
