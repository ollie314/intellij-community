package org.gradle;

public interface CategoryB extends CategoryA{
}
