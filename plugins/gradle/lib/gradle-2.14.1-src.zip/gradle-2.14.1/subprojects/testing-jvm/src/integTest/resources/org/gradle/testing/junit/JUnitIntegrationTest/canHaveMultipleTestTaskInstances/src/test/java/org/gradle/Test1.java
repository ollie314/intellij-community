package org.gradle;

import org.junit.Test;

public class Test1 {
    @Test
    public void ok() {
    }
}
