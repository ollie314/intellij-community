import org.junit.Test;

public class Ok2 {
    @Test
    public void ok() {
    }
}